﻿# Host: localhost  (Version 5.5.5-10.1.36-MariaDB)
# Date: 2019-10-29 10:18:33
# Generator: MySQL-Front 6.0  (Build 2.20)


#
# Structure for table "nilai"
#

DROP TABLE IF EXISTS `nilai`;
CREATE TABLE `nilai` (
  `nis` varchar(5) NOT NULL DEFAULT '',
  `kdpel` varchar(2) NOT NULL DEFAULT '',
  `nilai_pel` int(2) NOT NULL DEFAULT '0',
  `predikat` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`nis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "nilai"
#

INSERT INTO `nilai` VALUES ('1234','K9',100,'Baik');

#
# Structure for table "pelajaran"
#

DROP TABLE IF EXISTS `pelajaran`;
CREATE TABLE `pelajaran` (
  `kdpel` varchar(2) NOT NULL DEFAULT '',
  `namapel` varchar(20) NOT NULL DEFAULT '',
  `kkm` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kdpel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pelajaran"
#

INSERT INTO `pelajaran` VALUES ('K9','Agama',80),('L2','Kimia',75);

#
# Structure for table "siswa"
#

DROP TABLE IF EXISTS `siswa`;
CREATE TABLE `siswa` (
  `nis` varchar(5) NOT NULL DEFAULT '',
  `nama` varchar(30) NOT NULL DEFAULT '',
  `alamat` varchar(50) NOT NULL DEFAULT '',
  `kelas` varchar(10) NOT NULL DEFAULT '',
  `jurusan` varchar(4) NOT NULL DEFAULT '',
  PRIMARY KEY (`nis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "siswa"
#

INSERT INTO `siswa` VALUES ('1234','Sanding R','Banyumas','10','IPS'),('1365','Verdi','Banten','11','IPS'),('4569','Iren','Jakarta','11','IPS');

#
# Structure for table "users"
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userid` varchar(10) NOT NULL DEFAULT '',
  `pass` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "users"
#

INSERT INTO `users` VALUES ('sanding','123');
