<?php


if(isset($_POST['simpan'])){


 include('koneksi.php');

 //jika tombol tambah benar di klik maka lanjut prosesnya
 $kdpel   = $_POST['kdpel']; //membuat variabel 
 $namapel  = $_POST['namapel']; //membuat variabel
 $kkm  = $_POST['kkm']; 

 //melakukan query dengan perintah UPDATE untuk update data ke database dengan kondisi dimana id='$id' <- diambil dari inputan hidden id
 $update = mysql_query("UPDATE pelajaran SET kdpel='$kdpel', namapel='$namapel', kkm='$kkm' WHERE kdpel='$kdpel'") or die(mysql_error());

 //jika query update sukses
 if($update){
 
  header('location:view_mp.php');

 }else{

 header('location:view_mp.php');
 }

}else{ //jika tidak terdeteksi tombol simpan di klik

 //redirect atau dikembalikan ke halaman edit
 echo '<script>window.history.back()</script>';

}
?>
