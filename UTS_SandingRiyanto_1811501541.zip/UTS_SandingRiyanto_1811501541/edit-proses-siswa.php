<?php


if(isset($_POST['simpan'])){


 include('koneksi.php');


 $nis  = $_POST['nis']; 
 $nama  = $_POST['nama']; 
 $alamat  = $_POST['alamat'];
 $kelas  = $_POST['kelas'];
 $jurusan  = $_POST['jurusan'];



 $update = mysql_query("UPDATE siswa SET nis='$nis', nama='$nama', alamat='$alamat', kelas='$kelas', jurusan='$jurusan' WHERE nis='$nis'") or die(mysql_error());

 //jika query update sukses
 if($update){
 
  header('location:view_siswa.php');

 }else{

 header('location:view_siswa.php');
 }

}else{ //jika tidak terdeteksi tombol simpan di klik

 //redirect atau dikembalikan ke halaman edit
 echo '<script>window.history.back()</script>';

}
?>
