<!DOCTYPE html>
<html>
<head>
 <title>CRUD inentory lab ict</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

 
</head>
<body>
 
<div class="container">
  <div class="col-md-6">
    
 <h2 class="text-center mt-4">EDIT DATA NILAI MAHASISWA UBL</h2>
  <p class="text-center">
    <a class="text-center" href="home.php">Beranda</a> || <a href="tambah.php">Tambah Data</a></p>
    <hr color="blue">

<?php
 //memasukkan file koneksi ke database
 include('koneksi.php');

 //membuat variabel 
 $kdpel = $_GET['kdpel'];

 //melakukan query ke database dg SELECT 
 $show = mysql_query("SELECT * FROM pelajaran WHERE kdpel='$kdpel'");

 //cek apakah data dari hasil query ada atau tidak
 if(mysql_num_rows($show) == 0){

  //jika tidak ada data yg sesuai maka akan langsung di arahkan ke halaman depan atau beranda -> index.php
  echo '<script>window.history.back()</script>';

 }else{

  //jika data ditemukan, maka membuat variabel $data
  $data = mysql_fetch_assoc($show); //mengambil data ke database yang nantinya akan ditampilkan di form edit di bawah

 }
 ?>

   <form action="edit-proses-mp.php" method="post">
      <table cellpadding="3" cellspacing="0">
        <tr>
          <td>Kode</td>
          <td>:</td>
          <td><input type="text" name="kdpel" value="<?php echo $data['kdpel']; ?>" ></td>
        <tr>
            <td>Matakuliah</td>
            <td>:</td>
            <td><input type="text" name="namapel" value="<?php echo $data['namapel']; ?>" ></td>
        </tr>
        <tr>
            <td>SKS</td>
            <td>:</td>
            <td><input type="text" name="kkm" value="<?php echo $data['kkm']; ?>" ></td>
        </tr>

        <tr>
            <td> </td>
            <td></td>
            <td><input type="submit" name="simpan" value="Simpan"></td>
        </tr>
    </table>
  </form>
</div>
</div>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
