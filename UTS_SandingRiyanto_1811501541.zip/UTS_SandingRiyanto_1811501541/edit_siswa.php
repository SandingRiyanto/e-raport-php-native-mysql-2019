<!DOCTYPE html>
<html>
<head>
 <title>Edit</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

 
</head>
<body>
 
<div class="container">
  <div class="col-md-6">
    
 <h2 class="text-center mt-4">EDIT DATA MAHASISWA UBL</h2>
  <p class="text-center">
    <a class="text-center" href="home.php">Beranda</a> || <a href="tambah_mhs.php">Tambah Data Mahasiswa</a></p>
    <hr color="blue">

<?php
 
 include('koneksi.php');

 $nis = $_GET['nis'];
 
 $show = mysql_query("SELECT * FROM siswa WHERE nis='$nis'");

 
 if(mysql_num_rows($show) == 0){

  
  echo '<script>window.history.back()</script>';

 }else{

  
  $data = mysql_fetch_assoc($show); //mengambil data ke database yang nantinya akan ditampilkan di form edit di bawah

 }
 ?>

   <form action="edit-proses-siswa.php" method="post">
      <table cellpadding="3" cellspacing="0">
        <tr>
          <td>NIS</td>
          <td>:</td>
          <td><input type="text" name="nis" value="<?php echo $data['nis']; ?>" ></td>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" value="<?php echo $data['nama']; ?>" ></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><input type="text" name="alamat" size="30" value="<?php echo $data['alamat']; ?>" ></td>
        </tr>
        <tr>
            <td>Kelas</td>
            <td>:</td>
            <td><select name="kelas" value="<?php echo $data['kelas']; ?>">
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                </select></td>
        </tr>
        <tr>
            <td>Jurusan</td>
            <td>:</td>
            <td>
              <select name="jurusan" value="<?php echo $data['jurusan']; ?>">
                <option>IPA</option>
                <option>IPS</option>
              </select>
            </td>
        </tr>

        <tr>
            <td> </td>
            <td></td>
            <td><input type="submit" name="simpan" value="Simpan"></td>
        </tr>
    </table>
  </form>
</div>
</div>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
