<?php

//cek dahulu, apakah benar URL sudah ada GET nim -> hapus.php?nim=siswa_nim
if(isset($_GET['kdpel'])){

 //memasukkan file koneksi ke database
 include('koneksi.php');

 //membuat variabel $kdpel yg bernilai dari URL GET kdpel -> hapus.php?kdpel=siswa_kdpel
 $kdpel = $_GET['kdpel'];

 //cek ke database apakah ada data mahasiswa dengan kdpel='$kdpel'
 $cek = mysql_query("SELECT kdpel FROM pelajaran WHERE kdpel='$kdpel'") or die(mysql_error());

 //jika data mahasiswa tkdpelak ada
 if(mysql_num_rows($cek) == 0){

  //jika data tkdpelak ada, maka redirect atau dikembalikan ke halaman beranda
  echo '<script>window.history.back()</script>';

 }else{

  //jika data ada di database, maka melakukan query DELETE table siswa dengan kondisi dimana kdpel='$kdpel'
  $del = mysql_query("DELETE FROM pelajaran WHERE kdpel='$kdpel'");

  //jika query DELETE berhasil
  if($del){

  header('location:view_mp.php');
  }else{

  header('location:view_mp.php');

  }

 }

}else{

 //redirect atau dikembalikan ke halaman beranda
 echo '<script>window.history.back()</script>';

}
?>


 
