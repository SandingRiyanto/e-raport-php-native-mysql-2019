<?php

//cek dahulu, apakah benar URL sudah ada GET nim -> hapus.php?nim=siswa_nim
if(isset($_GET['nis'])){

 //memasukkan file koneksi ke database
 include('koneksi.php');

 //membuat variabel $nis yg bernilai dari URL GET kdmtk -> hapus.php?kdmtk=siswa_kdmtk
 $nis = $_GET['nis'];

 //cek ke database apakah ada data mahasiswa dengan nis='$nis'
 $cek = mysql_query("SELECT nis FROM siswa WHERE nis='$nis'") or die(mysql_error());

 //jika data mahasiswa tnisak ada
 if(mysql_num_rows($cek) == 0){

  //jika data tnisak ada, maka redirect atau dikembalikan ke halaman beranda
  echo '<script>window.history.back()</script>';

 }else{

  //jika data ada di database, maka melakukan query DELETE table siswa dengan kondisi dimana nis='$nis'
  $del = mysql_query("DELETE FROM siswa WHERE nis='$nis'");

  //jika query DELETE berhasil
  if($del){

  header('location:view_siswa.php');
  }else{

  header('location:view_siswa.php');

  }

 }

}else{

 //redirect atau dikembalikan ke halaman beranda
 echo '<script>window.history.back()</script>';

}
?>


 
