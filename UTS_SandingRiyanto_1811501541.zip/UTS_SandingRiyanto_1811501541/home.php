
<!DOCTYPE html>
<html>
<head>
 <title>Beranda</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>

<body>
  <div class="container">
  	<div class="row">
  	    <div class="col-md-6">  
		<h2 class="text-center mt-4">SISTEM E-RAPORT SMAN 1 SUMPIUH</h2>
		<hr color="blue">
		<p class="text-center">
		<a href="#">Beranda</a> || <a href="view_siswa.php">Data Siswa</a> || <a href="view_mp.php">Data Pelajaran</a> || <a href="view_nilai.php">Nilai Raport</a> || <a href="logout.php" class="mt-5"><b>LOGOUT</b></a></p>

<center>
	<table>
	  <tr><img src="img/logo-sma.png" class="rounded-circle" width="40%"></tr>
	</table>
</center>
<br><br>

  </div>
</div>

 <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
