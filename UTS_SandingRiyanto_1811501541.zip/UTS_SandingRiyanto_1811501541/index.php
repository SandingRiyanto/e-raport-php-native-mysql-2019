
<!DOCTYPE html>
<html>
<head>
 <title>Beranda</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>

<body>

	<nav class="navbar navbar-expand-lg navbar-light bg-primary fixed-top">
      <div class="container">
          <h3><i class="fas fa-cart-plus text-success mr-2"></i></h3>
          <a class="navbar-brand font-weight-bold" href="#">E-RAPORT</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto mr-4">
              <li class="nav-item active">
                <a class="nav-link" href="login.php"><strong>Login</strong> <span class="sr-only">(current)</span></a>
              </li>
              
            </ul>

           </div>
          </div>
        </nav>

        <br><br>

        <center>
          <table>
            <tr><img src="img/logo-sma.png" class="rounded-circle mt-5" width="15%"></tr>
          </table>
        </center>

        <div class="row">
          <div class="col-md-4">
            </div>
              <div class="col-md-4 mt-5">
                <marquee direction="right"><b>SELAMAT DATANG DI SISTEM E-RAPORT SMAN 1 SUMPIUH</b></marquee>
              </div>
            <div class="col-md-4"> 
            </div>
        </div>

         <div class="row">
          <div class="col-md-4">
            </div>
              <div class="col-md-4 mt-5">
                <marquee direction="left"><b>SILAHKAN LOGIN !</b></marquee>
              </div>
            <div class="col-md-4"> 
            </div>
        </div>


  </div>
</div>

 <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
