<?php
$host = "localhost"; //nama host
$user = "root"; //username phpMyAdmin
$pass = ""; //default password phpMyAdmin
$db = "db_uts"; //nama database

$koneksi = mysql_connect($host, $user, $pass) or die("Koneksi ke database gagal !");
mysql_select_db($db, $koneksi) or die("Tidak ada database yang dipilih !");
?>
