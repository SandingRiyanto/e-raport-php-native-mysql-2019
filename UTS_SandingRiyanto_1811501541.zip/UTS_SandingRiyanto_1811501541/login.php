<?php
//login.php

if(isset($_POST['login']))
{
    $vId    = $_POST['vId'];
    $vPass   = $_POST['vPass'];

    include "koneksi.php";
    $query="select * from users where userid='$vId' and pass='$vPass'";
    $result = mysql_query($query);

    if(mysql_num_rows($result) > 0)
    {
        session_start();
        $_SESSION['vId']        = $vId;
        $_SESSION['vPass']      = $vPass;
        echo"Login berhasil ! <br>";
        header('location:home.php');
    }else{
        echo"<div class='alert alert-danger container' role='alert'>UserID / Password SALAH !!!</div>";
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="login.css">
    <title>Login SPV</title>
  </head>
  <body>
    
    <div class="container">
            
        <h4 class="text-center mt-4"><i class="fas fa-sign-in-alt"></i>LOGIN !</h4>
        <hr>

        <form action="" method="post" name="input">
            <div class="form-group">
                <label>USERNAME</label>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fas fa-user"></i></div>
                    </div>
                    <input type="text" name="vId" class="form-control" placeholder="Masukkan Username Anda">
                </div>
            </div>

            <div class="form-group">
                <label>PASSWORD</label>

                <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text"><i class="fas fa-lock"></i></div>
                    </div>
                    <input type="password" name="vPass" class="form-control" placeholder="Masukkan Password Anda">
                </div>
            </div>

            <!--Tombol-->
            <button class="btn btn-primary" type="submit" name="login">LOGIN</button>
            <button class="btn btn-danger" type="reset" name="reset">RESET</button>
        </form>

    </div>

    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
  </body>
</html>