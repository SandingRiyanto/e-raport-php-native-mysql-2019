<?php 
include('koneksi.php');

  //query ke database dg SELECT table mahasiswa diurutkan berdasarkan NIM paling besar
  $siswa = mysql_query("SELECT * FROM siswa") or die(mysql_error());
  $pelajaran = mysql_query("SELECT * FROM pelajaran") or die(mysql_error());

?>

<!DOCTYPE html>
<html>
<head>
 <title>Form Input Data Nilai</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>

<div class="container">
  <div class="col-md-6">
    
 <h2 class="text-center mt-4">INPUT DATA NILAI</h2>
  <p class="text-center">
    <a class="text-center" href="home.php">Beranda</a> || <a href="view_nilai.php">Data Raport</a></p>
    <hr color="blue">
      <form action="tambah-proses-nilai.php" method="post" name="cekForm" onSubmit="return cekFile()">
        <table cellpadding="3" cellspacing="0">
          <tr>
              <td>NIS/Nama</td>
              <td>:</td>
              <td><select name="nis">
                <?php
                 while($data = mysql_fetch_assoc($siswa)){
                  echo '<option value='.$data['nis'].'>'.$data['nis'].'-'.$data['nama'].'</option>';
                }
                ?>
                </select></td>
          </tr>
          <tr>
              <td>Kode/Pelajaran</td>
              <td>:</td>
              <td><select name="kdpel">
                <?php
                 while($data = mysql_fetch_assoc($pelajaran)){
                  echo '<option value='.$data['kdpel'].'>'.$data['kdpel'].'-'.$data['namapel'].'</option>';
                }
                ?>
                </select></td>
          </tr>
          <tr>
              <td>Nilai Pelajaran</td>
              <td>:</td>
              <td><input type="text" name="nilai_pel" size="30"></td>
          </tr>
          <tr>
              <td>Predikat</td>
              <td>:</td>
              <td><input type="text" name="predikat" size="30"></td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td><input type="submit" class="btn btn-outline-primary" name="tambah" value="Tambah"></td>
          </tr>
      </table>
    </form>

  </div>
</div>

    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
