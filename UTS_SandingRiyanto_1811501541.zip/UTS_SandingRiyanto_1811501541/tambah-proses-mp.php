<?php

//cek dahulu, jika tombol tambah di klik
if(isset($_POST['tambah'])){

 // memasukkan file koneksi ke database
 include('koneksi.php');

 //jika tombol tambah benar di klik maka lanjut prosesnya
 $kdpel  = $_POST['kdpel']; //membuat variabel $nama barang dan datanya dari inputan nama barang
 $namapel  = $_POST['namapel']; //membuat variabel $nama dan datanya dari inputan Nama Lengkap
 $kkm  = $_POST['kkm']; //membuat variabel $semester dan datanya dari inputan Semester
 
//melakukan query dengan perintah INSERT INTO untuk memasukkan data ke database
 $input = mysql_query("INSERT INTO pelajaran VALUES('$kdpel', '$namapel', '$kkm')") or die(mysql_error());

 //jika query input sukses
 if($input){

 	header('location:view_mp.php');


 }else{

 	header('location:view_mp.php');

 }

}else{ //jika tidak terdeteksi tombol tambah di klik

 //redirect atau dikembalikan ke halaman tambah
 echo '<script>window.history.back()</script>';

}
?>
