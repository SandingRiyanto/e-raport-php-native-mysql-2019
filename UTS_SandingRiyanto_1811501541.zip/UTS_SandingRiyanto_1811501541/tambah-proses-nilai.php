<?php

include "koneksi.php";
if(isset($_POST['tambah'])){
    $nis = $_POST['nis'];
    $kdpel = $_POST['kdpel'];
    $nilai_pel = $_POST['nilai_pel'];
    $predikat = $_POST['predikat'];
    $query = "insert into nilai values (
                '$nis','$kdpel','$nilai_pel','$predikat')";
    $result = mysql_query($query);

    if($result){
        header('location:view_nilai.php');

    }else{
        header('location:view_nilai.php');
	}
}
?>