<?php

if(isset($_POST['tambah'])){

 include('koneksi.php');

 $nis		= $_POST['nis']; 
 $nama		= $_POST['nama']; 
 $alamat	= $_POST['alamat'];
 $kelas		= $_POST['kelas']; 
 $jurusan		= $_POST['jurusan']; 

//melakukan query dengan perintah INSERT INTO untuk memasukkan data ke database
 $input = mysql_query("INSERT INTO siswa VALUES('$nis', '$nama', '$alamat', '$kelas', '$jurusan')") or die(mysql_error());

 if($input){

 	header('location:view_siswa.php');

 }else{

 	header('location:view_siswa.php');

 }

}else{ 

 echo '<script>window.history.back()</script>';

}
?>
