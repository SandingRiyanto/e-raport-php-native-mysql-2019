<!DOCTYPE html>
<html>
<head>
 <title>Form Input Data Pelajaran</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>

<div class="container">
  <div class="col-md-6">
    
 <h2 class="text-center mt-4">INPUT DATA PELAJARAN</h2>
  <p class="text-center">
    <a class="text-center" href="home.php">Beranda</a> || <a href="view_mp.php">Data Pelajaran</a></p>
    <hr color="blue">
      <form action="tambah-proses-mp.php" method="post" name="cekForm" onSubmit="return cekFile()">
        <table cellpadding="3" cellspacing="0">
          <tr>
              <td>Kode</td>
              <td>:</td>
              <td><input type="text" name="kdpel" size="30" ></td>
          </tr>
          <tr>
              <td>Pelajaran</td>
              <td>:</td>
              <td><input type="text" name="namapel" size="30"></td>
          </tr>
          <tr>
              <td>KKM</td>
              <td>:</td>
              <td><input type="text" name="kkm" size="30"></td>
          </tr>
          <tr>
            <td> </td>
            <td></td>
            <td><input type="submit" class="btn btn-outline-primary" name="tambah" value="Tambah"></td>
          </tr>
      </table>
    </form>

  </div>
</div>

    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
