<!DOCTYPE html>
<html>
<head>
 <title>Form Input Data Siswa</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>

<div class="container">
  <div class="col-md-6">
    
 <h2 class="text-center mt-4">INPUT DATA SISWA</h2>
  <p class="text-center">
    <a class="text-center" href="home.php">Beranda</a> || <a href="view_siswa.php">Data Siswa</a></p>
    <hr color="blue">
      <form action="tambah-proses-siswa.php" method="post" name="cekForm" onSubmit="return cekFile()">
        <table cellpadding="3" cellspacing="0">
          <tr>
              <td>NIS</td>
              <td>:</td>
              <td><input type="text" name="nis" size="30" ></td>
          </tr>
          <tr>
              <td>Nama</td>
              <td>:</td>
              <td><input type="text" name="nama" size="30"></td>
          </tr>
          <tr>
              <td>Alamat</td>
              <td>:</td>
              <td><input type="text" name="alamat" size="30"></td>
          </tr>
          <tr>
            <td>Kelas</td>
              <td>:</td>
              <td><select name="kelas">
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                </select></td>
          </tr>
          <tr>
              <td>Jurusan</td>
              <td>:</td>
              <td>
                <select name="jurusan">
                  <option value="IPA">IPA</option>
                  <option value="IPS">IPS</option>
                </select>
              </td>
          </tr>



          <tr>
            <td> </td>
            <td></td>
            <td><input type="submit" class="btn btn-outline-primary mt-3" name="tambah" value="Tambah"></td>
          </tr>
      </table>
    </form>

  </div>
</div>

    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
