
<!DOCTYPE html>
<html>
<head>
 <title>DATA SISWA</title>
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>

<body>
  <div class="container">
    <div class="col-md-6">  
      <h2 class="text-center mt-4">DATA SISWA SMAN 1 SUMPIUH</h2>
      <p class="text-center">
      <a href="home.php">Beranda</a> || <a href="tambah_siswa.php">Tambah Data Siswa</a></p>
      <hr color="red">
      <table cellpadding="5" cellspacing="0" border="1" align="center">
      <tr bgcolor="#FE4535" class="text-center">
        
       <th>No</th>
       <th>NIS</th>
       <th>Nama</th>
       <th>Alamat</th>
       <th>Kelas</th>
       <th>Jurusan</th>
       <th>Opsi</th>
      </tr>

<?php
  //masuk file koneksi ke database
  include('koneksi.php');

  //query ke database dg SELECT table mahasiswa diurutkan berdasarkan NIM paling besar
  $query = mysql_query("SELECT * FROM siswa") or die(mysql_error());

  //cek, apakah hasil query di atas mendapatkan hasil atau tidak (data kosong atau tidak)
  if(mysql_num_rows($query) == 0){ //ini artinya jika data hasil query di atas kosong

   //jika data kosong, maka akan menampilkan row kosong
   echo '<tr><td colspan="6">Tidak ada data!</td></tr>';

  }else{ //else ini artinya jika data hasil query ada (data diu database tidak kosong)

   //jika data tidak kosong, maka akan melakukan perulangan while
   $no = 1; //membuat variabel $no untuk membuat nomor urut
   while($data = mysql_fetch_assoc($query)){ //perulangan while dg membuat variabel $data yang akan mengambil data di database

    //menampilkan row dengan data di database
echo '<tr>';
     echo '<td>'.$no.'</td>'; 
     echo '<td>'.$data['nis'].'</td>'; 
     echo '<td>'.$data['nama'].'</td>'; 
     echo '<td>'.$data['alamat'].'</td>';
     echo '<td>'.$data['kelas'].'</td>'; 
     echo '<td>'.$data['jurusan'].'</td>'; 
     echo '<td><a class="btn btn-outline-success" href="edit_siswa.php?nis='.$data['nis'].'">Edit</a> || <a class="btn btn-outline-danger" href="hapus-siswa.php?nis='.$data['nis'].'" onclick="return confirm(\'Anda Yakin Menghapus Data Ini ?\')">Hapus</a></td>'; 
echo '</tr>';

    $no++;

   }

}
?>
 </table>
 </div>
</div>

 <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
